import { useEffect, useRef, useState } from "react";
import Video from "../components/video";
import { useRouter } from "next/router";
import Script from "next/script";
import useScript from "@/components/usehooks-ts";
import axios from "axios";

export default function Play() {
    const route = useRouter();
    const id = route.query.videoId as string;
    var temp;
    const [applicationData, setApplicationData] = useState({ videoId: '' });
    useEffect(() => {
        const userRequest = async () => {
            const res = await axios.get(`http://localhost:3000/api/youtubeDownloader?videoId=${id}`, { timeout: 20000 });
            if (res.data.videoId !== 'undefined' && res.data.videoId !== 'error') {
                console.log(res.data.videoId, '인사이드')

                setApplicationData(res.data);
            }
            // return;
            // }
            // console.log(res.data.videoId, applicationData.videoId, id);
        };
        userRequest();
    }, [id]);

    // const status = useScript(`/scripts/puzzle.js`, {
    //     shouldPreventLoad: false,
    //     removeOnUnmount: false,
    // })

    return (
        <>

            {/* {console.log(applicationData.videoId, id)} */}
            {applicationData.videoId === id && <Video data={{ videoId: id }} />}
        </>

    )
}




